# Capstone Project

select * from data_cleaned; 

# 1. Write an SQL query to identify the age group which is taking more loan and then calculate the sum of all of the balances of it?

select case
   when Age <18 then 'Under 18'
   when age between 18 and 24 then '18-24'
   when age between 25 and 34 then '25-34'
   when age between 35 and 44 then '35-44'
   when age between 45 and 54 then '45-54'
   when age between 55 and 64 then '55-64'
   when age between 65 and 74 then '65-74'
   when age between 75 and 84 then '75-84'
   when age between 85 and 94 then '85-94'
   when age between 95 and 104 then '95-104'
 END as age_range, 
 Count(*) as count,
 sum(balance) as total_balance
 from data_cleaned
 where loan = ' yes '
 group by age_range
 order by count desc;
 #the age group between 25-34 as taken more loans with total count of 2331 as a balance of 1781193


# 2.Write an SQL query to calculate for each record if a loan has been taken less than 100, then  calculate the fine of 15% of the current balance and create a temp table and then add the amount for each month from that temp table? 
SELECT Balance, (Balance/100) * 15 as fine, ((Balance/100) * 15)+ Balance as total
From data_cleaned
Where Balance < 100;
#the fine contains 43500 and the total balance is 333500


# 3.Write an SQL query to calculate each age group along with each department's highest balance record? 

select case
   when Age <18 then 'Under 18'
   when age between 18 and 24 then '18-24'
   when age between 25 and 34 then '25-34'
   when age between 35 and 44 then '35-44'
   when age between 45 and 54 then '45-54'
   when age between 55 and 64 then '55-64'
   when age between 65 and 74 then '65-74'
   when age between 75 and 84 then '75-84'
   when age between 85 and 94 then '85-94'
   when age between 95 and 104 then '95-104'
 END as age_range,
 Job, sum(balance) as total_amount
from data_cleaned
group by age_range
order by total_amount desc;
#here the technician department with the age group of 35-44 has an highest balance of 19458955


# 4.Write an SQL query to find the secondary highest education, where duration is more than 150. The query should contain only married people, and then calculate the interest amount? (Formula interest => balance*15%). 
select Education, duration, marital, ((Balance/100) * 15) + Balance as interest
from data_cleaned
where Education = ' secondary '
and duration > 150
and marital = ' married '
order by interest desc;
#here we can see secondary education with onluy married marital status with 15% interest. 


# 5.Write an SQL query to find which profession has taken more loan along with age?
select case
   when Age <18 then 'Under 18'
   when age between 18 and 24 then '18-24'
   when age between 25 and 34 then '25-34'
   when age between 35 and 44 then '35-44'
   when age between 45 and 54 then '45-54'
   when age between 55 and 64 then '55-64'
   when age between 65 and 74 then '65-74'
   when age between 75 and 84 then '75-84'
   when age between 85 and 94 then '85-94'
   when age between 95 and 104 then '95-104'
END as age_range, 
Job, count(*) as count
FROM data_cleaned
where loan = ' yes ' 
group by Job
order by count desc;
#here blue collar profession with the age range 25-34 has taken more loan 


# 6.Write an SQL query to calculate each month's total balance and then calculate in which month the highest amount of transaction was performed?
select Month, balance, sum(Balance) as total_sum
from data_cleaned
group by Month
order by balance desc;
# the highest transactions was performed on august month.